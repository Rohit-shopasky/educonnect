export interface IClass{
  standard:string,
  section:string,
  instituteId:string,
  id?:string,
}
