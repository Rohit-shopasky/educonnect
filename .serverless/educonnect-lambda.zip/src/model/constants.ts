export enum profileType{
    PARENT,
    STAFF,
    STUDENT
}

export enum staffType{
    TEACHER="TEACHER",
    ADMIN="ADMIN"
}

export enum gender {
  MALE = "MALE",
  FEMALE = "FEMALE",
  OTHER = "OTHER",
}