export enum profileType{
    PARENT,
    STAFF,
    STUDENT
}